class APrep < ActiveRecord::Base
    belongs_to :allergen
    belongs_to :dish
end